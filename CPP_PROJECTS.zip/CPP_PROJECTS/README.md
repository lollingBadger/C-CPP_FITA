# C++ Multi-File Teaching Workspace

This workspace is designed to explain how C++ projects are split into multiple files and compiled from the command line with `g++`.

## Structure

- `lesson1_basic/`: header + source + main in a small example.
- `lesson2_separate_build/`: compile into object files first, then link.
- `lesson3_static_library/`: build a static library and link it to an app.

## Lesson 1: Basic Multi-File Build

```powershell
cd lesson1_basic
g++ -std=c++17 -Wall -Wextra -Iinclude src/main.cpp src/calculator.cpp -o bin/app.exe
.\bin\app.exe
```

Flag notes for students:

- `-W...` enables warning options.
	- `-Wall`: enables a common set of useful warnings.
	- `-Wextra`: enables additional warnings beyond `-Wall`.
- `-Iinclude` adds `include` to the header search path.
- `-o bin/app.exe` sets the output executable file path.
- Why no space in `-Wextra`?
	- `Wextra` is the warning option name itself, so it is written as one flag: `-Wextra`.
	- Writing `-W extra` changes how arguments are parsed and is not the standard form for this warning flag.

## Lesson 2: Separate Compilation and Linking

```powershell
cd lesson2_separate_build
mkdir bin,obj -ErrorAction SilentlyContinue

g++ -std=c++17 -Wall -Wextra -Iinclude -c src/main.cpp -o obj/main.o
g++ -std=c++17 -Wall -Wextra -Iinclude -c src/logger.cpp -o obj/logger.o
g++ -std=c++17 -Wall -Wextra -Iinclude -c src/file_ops.cpp -o obj/file_ops.o

g++ obj/main.o obj/logger.o obj/file_ops.o -o bin/app.exe
.\bin\app.exe
```

Flag notes for students:

- `-c` compiles each `.cpp` into an object file (`.o`) without linking.
- `-Iinclude` lets the compiler find headers inside the `include` folder.
- `-o obj/main.o` (or similar) names the output object file for each compile step.
- Final link command:
	- `g++ obj/main.o obj/logger.o obj/file_ops.o -o bin/app.exe`
	- This combines all object files into one executable.

## Lesson 3: Build and Use a Static Library

```powershell
cd lesson3_static_library
mkdir bin,obj,lib -ErrorAction SilentlyContinue

g++ -std=c++17 -Wall -Wextra -Iinclude -c src/text_tools.cpp -o obj/text_tools.o
ar rcs lib/libtexttools.a obj/text_tools.o

g++ -std=c++17 -Wall -Wextra -Iinclude src/main.cpp -Llib -ltexttools -o bin/app.exe
.\bin\app.exe
```

Flag notes for students:

- `-c` creates `obj/text_tools.o` from `src/text_tools.cpp`.
- `ar rcs lib/libtexttools.a obj/text_tools.o` creates a static library archive:
	- `r`: insert/replace object files in archive.
	- `c`: create archive if it does not exist.
	- `s`: generate symbol index for faster linking.
- `-Llib` adds `lib` as a library search path.
- `-ltexttools` links with `libtexttools.a` (prefix `lib` and suffix `.a` are implied).
- `-o bin/app.exe` sets the final executable name and location.


1. Headers (`.h`) declare interfaces.
2. Source files (`.cpp`) implement interfaces.
3. `main.cpp` uses those interfaces.
4. You can compile and link in one step, or split into two steps.
5. Static libraries package reusable object code.
