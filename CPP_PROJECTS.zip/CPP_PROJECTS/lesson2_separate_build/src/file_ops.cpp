#include <fstream>
#include <string>
#include "file_ops.h"

void append_line(const std::string& file_name, const std::string& line) {
    std::ofstream out(file_name, std::ios::app);
    out << line << '\n';
}

int count_lines(const std::string& file_name) {
    std::ifstream in(file_name);
    std::string line;
    int count = 0;

    while (std::getline(in, line)) {
        ++count;
    }

    return count;
}
