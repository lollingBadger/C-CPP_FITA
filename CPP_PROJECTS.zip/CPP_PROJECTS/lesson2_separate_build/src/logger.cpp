#include <iostream>
#include "logger.h"

void log_message(const std::string& message) {
    std::cout << "[LOG] " << message << '\n';
}
