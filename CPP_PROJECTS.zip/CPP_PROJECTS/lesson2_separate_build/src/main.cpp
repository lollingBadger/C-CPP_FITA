#include <string>
#include "logger.h"
#include "file_ops.h"

int main() {
    const std::string file_name = "notes.txt";

    append_line(file_name, "Line 1: separate compilation demo");
    append_line(file_name, "Line 2: each .cpp can become an object file");

    const int total = count_lines(file_name);
    log_message("Total lines in " + file_name + ": " + std::to_string(total));

    return 0;
}
