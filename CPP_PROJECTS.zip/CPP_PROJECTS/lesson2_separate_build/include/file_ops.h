#ifndef FILE_OPS_H
#define FILE_OPS_H

#include <string>

void append_line(const std::string& file_name, const std::string& line);
int count_lines(const std::string& file_name);

#endif
