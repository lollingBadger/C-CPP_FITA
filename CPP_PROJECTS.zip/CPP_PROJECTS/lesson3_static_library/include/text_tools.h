#ifndef TEXT_TOOLS_H
#define TEXT_TOOLS_H

#include <string>

std::string to_uppercase(const std::string& input);
std::string reverse_text(const std::string& input);

#endif
