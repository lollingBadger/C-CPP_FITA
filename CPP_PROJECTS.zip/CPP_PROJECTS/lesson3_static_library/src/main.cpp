#include <iostream>
#include <string>
#include "text_tools.h"

int main() {
    const std::string text = "multi file project";

    std::cout << "Original : " << text << '\n';
    std::cout << "Upper    : " << to_uppercase(text) << '\n';
    std::cout << "Reversed : " << reverse_text(text) << '\n';

    return 0;
}
