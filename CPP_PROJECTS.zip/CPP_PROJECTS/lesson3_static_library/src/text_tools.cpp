#include <algorithm>
#include <cctype>
#include "text_tools.h"

std::string to_uppercase(const std::string& input) {
    std::string output = input;

    std::transform(output.begin(), output.end(), output.begin(), [](unsigned char c) {
        return static_cast<char>(std::toupper(c));
    });

    return output;
}

std::string reverse_text(const std::string& input) {
    std::string output = input;
    std::reverse(output.begin(), output.end());
    return output;
}
