#ifndef CALCULATOR_H
#define CALCULATOR_H

int add(int a, int b); // forward declaration of add function
int multiply(int a, int b); // forward declaration of multiply function

#endif
