#include <iostream>
#include "calculator.h"

int main() {
    const int x = 6;
    const int y = 7;

    std::cout << "x + y = " << add(x, y) << '\n';
    std::cout << "x * y = " << multiply(x, y) << '\n';

    return 0;
}
